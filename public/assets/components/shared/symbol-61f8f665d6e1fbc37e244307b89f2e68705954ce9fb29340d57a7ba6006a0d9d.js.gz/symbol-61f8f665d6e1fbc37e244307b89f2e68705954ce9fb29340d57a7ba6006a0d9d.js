import React from "react";

export const Point = ({ children }) => (
  <>
    &#8226;
    {" "}
    {children}
  </>
);
