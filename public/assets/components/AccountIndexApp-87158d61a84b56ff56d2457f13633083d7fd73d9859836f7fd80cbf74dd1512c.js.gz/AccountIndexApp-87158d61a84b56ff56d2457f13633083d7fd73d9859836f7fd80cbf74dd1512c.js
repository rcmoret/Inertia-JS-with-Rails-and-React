import React from "react";

import App from "./AccountIndex/App";

export default props => App(props);

