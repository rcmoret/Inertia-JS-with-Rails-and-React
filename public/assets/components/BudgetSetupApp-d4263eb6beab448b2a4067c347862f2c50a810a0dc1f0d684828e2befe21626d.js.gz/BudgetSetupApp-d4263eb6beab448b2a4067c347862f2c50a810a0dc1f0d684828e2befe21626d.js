import React from "react";
import App from "./BudgetSetup/App";

export default props => App(props);
