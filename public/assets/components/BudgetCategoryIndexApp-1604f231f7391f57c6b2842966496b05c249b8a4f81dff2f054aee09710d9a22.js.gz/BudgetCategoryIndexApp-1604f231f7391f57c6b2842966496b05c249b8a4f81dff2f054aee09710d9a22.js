import React from "react";

import App from "./BudgetCategoryIndex/App";

export default props => App(props);
