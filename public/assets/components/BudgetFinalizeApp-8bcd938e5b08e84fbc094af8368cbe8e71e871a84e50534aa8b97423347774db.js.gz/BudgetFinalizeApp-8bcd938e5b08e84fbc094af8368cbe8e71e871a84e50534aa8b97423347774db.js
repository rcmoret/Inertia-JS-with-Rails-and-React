import React from "react";
import App from "./BudgetFinalize/App";

export default props => App(props);
