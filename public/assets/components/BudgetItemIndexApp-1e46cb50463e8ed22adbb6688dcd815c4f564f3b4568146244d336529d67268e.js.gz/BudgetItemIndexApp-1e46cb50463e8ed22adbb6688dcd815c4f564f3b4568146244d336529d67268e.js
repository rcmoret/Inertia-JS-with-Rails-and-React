import React from "react";
import App from "./BudgetItemIndex/App";

export default props => App(props);
