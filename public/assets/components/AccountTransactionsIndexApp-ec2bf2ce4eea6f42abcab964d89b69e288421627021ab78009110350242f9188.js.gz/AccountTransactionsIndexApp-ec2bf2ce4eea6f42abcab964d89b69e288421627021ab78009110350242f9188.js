import React from "react";

import { App } from "./AccountTransactionsIndex/App";

export default props => App(props);
