export const shared = {
  pending: "pending",
};
