module.exports = {
  theme: {
    extend: {}
  },
  variants: {
    extend: {
      backgroundColor: ['even', 'odd'],
    },
  },
  plugins: []
};
